<template>
    <div>
        <h1>Comment Index</h1>
    </div>
</template>
<script>
export default {
    
}
</script>
<style scoped>

</style>